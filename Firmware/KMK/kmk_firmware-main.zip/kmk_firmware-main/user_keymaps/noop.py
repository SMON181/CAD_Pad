import sys


def main():
    sys.exit(0)
