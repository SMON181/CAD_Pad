# Osprette

The [Osprette](https://github.com/smores56/osprette) is a unibody, 34 key keyboard designed by S'mores. It uses a Pro-Micro footprint.
