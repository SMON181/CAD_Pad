# ScottoLong

![Top Shot](https://user-images.githubusercontent.com/8194147/200442213-ce094beb-b315-4e57-ab6c-12bc357095db.jpg)

Please see the [ScottoLong](https://github.com/joe-scotto/scottokeebs/tree/main/ScottoLong) GitHub page for details on how and what with to build this board.
